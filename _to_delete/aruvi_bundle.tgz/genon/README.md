# genon — generation-on-generation lab

Pre-warmed canonical plans, adapted to any teacher duration matrix without
regenerating content. Canonical plans are authored at a standardized N × 40 min;
all timetable variation is handled downstream.

## Architecture (v0.2, phase-centric)

    Pedagogical source (constitutions, unchanged pedagogy)
      │  one LLM generation per chapter, at N × 40
      ▼
    compile_stream.py — pure REWRITER: plan JSON → canonical phase stream
      (stable phase IDs, roles, unit table = reference partition; provably
       verbatim content — inventory audit)
      ▼
    partition.py — DETERMINISTIC: stream + duration matrix → full plan
      (role-aware DP boundary choice; adaptive fill tolerance 18→25→33%;
       mid-phase split only as last resort; derived period_ref / handoff
       remap / homework re-seat; seam notes flagged `seam_pending_llm`)
      ▼
    Teacher lesson plan in her time mould — Rs. 0, milliseconds

Optional LLM seam pass (Sonnet/Haiku, delta-only) polishes flagged seam notes.

## Genon constitutional amendments — LIVE since 2026-07-24 (amended/)

SS-secondary LP (v1.1) + assessment (v1.2) constitutions, applied directly to
the live SaaS texts (data/content/constitutions/.../social_sciences/secondary/):
- LP Rule 14: every time band carries `band_id` ("P<unit>.<n>") and `role`
  (hook | development | consolidation); every competency edge carries
  `band_refs`; handoff LO rows copy band_refs verbatim.
- LP time input: exactly ONE standard row (40 min ≤ VII, 45 VIII, 50 IX) —
  the teacher's duration mix never reaches generation (partition-time only).
- Assessment: items carry `phase_ref` = source LO's band_refs, verbatim
  (Rule 6 identity extended to band level). Applied on the live v1.1 base,
  preserving the MCQ answer-distribution rule → v1.2.
Reproduced by make_amendments.py as surgical edits on the archived
pre-amendment texts (amended/originals/) — everything else byte-identical.
amended/*.txt are exact copies of the live files.

## v0.1 (delta-over-period approach, kept for baseline)

genon_adaptation_doc.md + apply_delta.py + run_genon.py: model emits a compact
repartition delta against the period-centric plan; code applies it. Superseded
by the phase-centric pipeline but useful to benchmark model repartition ability.

## Test results (SS IX ch 5, canonical 14 × 40 = 560 min, 56 phases)

| matrix        | cuts        | splits | seam periods | edges kept |
|---------------|-------------|--------|--------------|------------|
| 12 × 45       | whole-phase | 0      | 6            | 30/30      |
| 16 × 35       | whole-phase | 0      | 6            | 30/30      |
| 10×40 + 4×30  | whole-phase | 0      | 0            | 30/30      |

Roles/phase_refs in these runs are compiler-INFERRED (pre-v1.1 plan). Next:
regenerate ch 5 live with the v1.1 LP constitution so roles and band_refs are
DECLARED, recompile, and re-partition.

## Files

- amended/lesson_plan_constitution_v1.1.txt · amended/assessment_constitution_v1.1.txt
- make_amendments.py — regenerates the amended texts from v1.0 sources
- compile_stream.py · partition.py — the v0.2 pipeline
- out/ch05_stream.json · out/ch05_plan_*.json — compiled stream + 3 adapted plans
- genon_adaptation_doc.md · apply_delta.py · run_genon.py · dry_run_test.py — v0.1
